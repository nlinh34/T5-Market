export const Role = {
  ADMIN: 0,
  MANAGER: 1,
  MOD: 2,
  SELLER: 3,
  STAFF: 4,
  USER: 5,
};
