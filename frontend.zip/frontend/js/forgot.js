document.getElementById("forgotForm").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Yêu cầu khôi phục đã được gửi!");
});
